ESE224 Homework 02

Question 1:
Run .cpp file with Q1.txt in same directory as .cpp file.
.cpp will create a .txt file called formattedValues.txt with correct numbers within.

Question 2:
Run .cpp and enter two numbers consecutively.  Any number resulting in a 0 harmonic mean will terminate.

Question 3:
Run .cpp and enter any string.  Enter a q or Q to terminate.

Question 4:
Run .cpp, observe output.  No user interaction required.
