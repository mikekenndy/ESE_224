#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <time.h>

using namespace std;

void printMessage(string, bool, bool);

string loadRandomWord(string);


